package com.lagou.edu.factory;

import com.alibaba.druid.util.StringUtils;
import com.lagou.edu.Annotation.Autowired;
import com.lagou.edu.Annotation.Service;
import com.lagou.edu.Annotation.Transactional;
import org.reflections.Reflections;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author hetiansheng
 * @date 2020/1/15
 */
public class BeanFactoryAnno {

    /**
     * Bean对象容器（Map）
     */
    private static final Map<String, Object> beanMap = new HashMap<String, Object>();

    /**
     * 根据包名扫描含有@Service/@Autowired/@Transactional注解的类或者属性进行相对应的处理
     *
     * @param packageName 包路径
     */
    public static void initScan(String packageName) throws Exception {
        Reflections reflections = new Reflections(packageName);

        //处理含有@Service注解的类实例化加入beanMap容器管理
        handleServiceAnno(reflections);

        //处理含有@Autowired注解的属性，给其实例化
        handleAutowiredAnno();

        //处理含有@Autowired注解的类，将其生成代理对象，重新装配回beanMap
        handleTransactionalAnno();
    }

    /**
     * 处理含有@Service注解的类实例化加入beanMap容器管理
     *
     * @param reflections
     * @throws Exception
     */
    private static void handleServiceAnno(Reflections reflections) throws Exception {
        Set<Class<?>> setService = reflections.getTypesAnnotatedWith(Service.class);
        for (Class<?> c : setService) {
            Object bean = c.newInstance();
            Service annotation = c.getAnnotation(Service.class);
            //如果注解@Service注解有value值，则key使用value，否则类名首字母小写
            if (StringUtils.isEmpty(annotation.value())) {
                //获取类实现的第一个接口作为key
                Class<?> anInterface = c.getInterfaces()[0];
                if (!StringUtils.isEmpty(anInterface.getSimpleName())) {
                    //将类名首字母转为小写
                    beanMap.put(toLowerCaseFirstOne(anInterface.getSimpleName()), bean);
                }
            } else {
                beanMap.put(annotation.value(), bean);
            }
        }
    }

    /**
     * 处理含有@Autowired注解的属性，给其实例化
     *
     * @throws Exception
     */
    private static void handleAutowiredAnno() throws Exception {
        for (Object o : beanMap.values()) {
            Class<?> aClass = o.getClass();
            Field[] declaredFields = aClass.getDeclaredFields();
            for (Field field : declaredFields) {
                //允许访问私有变量
                field.setAccessible(true);
                //判断此变量是否使用了@Autowired注解
                boolean isUsedAnnotation = field.isAnnotationPresent(Autowired.class);
                if (isUsedAnnotation) {
                    Object o1 = beanMap.get(field.getName());
                    //给有@Autowired的注解赋值
                    field.set(o, o1);
                }
            }
        }
    }

    /**
     * 处理含有@Autowired注解的类，将其生成代理对象，重新装配回beanMap
     */
    private static void handleTransactionalAnno() {
        ProxyFactory proxyFactory = (ProxyFactory) beanMap.get("proxyFactory");
        for (Map.Entry<String, Object> stringObjectEntry : beanMap.entrySet()) {
            Object value = stringObjectEntry.getValue();
            Class<?> aClass = value.getClass();
            if (aClass.isAnnotationPresent(Transactional.class)) {
                //如果实现了接口，使用jdk动态代理，否则使用CGLib动态代理
                if(aClass.getInterfaces().length > 0){
                    Object jdkProxy = proxyFactory.getJdkProxy(value);
                    beanMap.put(stringObjectEntry.getKey(), jdkProxy);
                }else {
                    Object jdkProxy = proxyFactory.getCglibProxy(value);
                    beanMap.put(stringObjectEntry.getKey(), jdkProxy);
                }
            }
        }
    }

    /**
     * 根据注解名获取实例
     *
     * @param beanName 注解的名称
     * @return 对应实例
     */
    public static Object getBean(String beanName) {
        return beanMap.get(beanName);
    }

    /**
     * 字符串首字母转为小写
     *
     * @param s
     * @return
     */
    public static String toLowerCaseFirstOne(String s) {
        if (Character.isLowerCase(s.charAt(0))) {
            return s;
        } else {
            return (new StringBuilder()).append(Character.toLowerCase(s.charAt(0))).append(s.substring(1)).toString();
        }
    }
}
