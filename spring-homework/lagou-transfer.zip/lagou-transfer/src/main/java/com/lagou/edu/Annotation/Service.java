package com.lagou.edu.Annotation;

import java.lang.annotation.*;

/**
 * @author hetiansheng
 * @date 2020/1/15
 */

@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface Service {
    String value() default "";
}
