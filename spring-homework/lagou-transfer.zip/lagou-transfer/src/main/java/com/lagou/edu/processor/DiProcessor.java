package com.lagou.edu.processor;

import com.lagou.edu.Annotation.Autowired;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * @author hetiansheng
 * @date 2020/1/15
 */
public class DiProcessor implements BeanPostProcessor {

    //@Autowired
    //private ApplicationContext applicationContext;

    /**
     * bean初始化之前要调用的方法，这里直接返回
     *
     * @param bean
     * @param beanName
     * @return
     * @throws BeansException
     */
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }

    /**
     * bean初始化之后要调用的方法，这里判断如果有自定义注解@Autowired时，做进一步处理
     *
     * @param bean
     * @param beanName
     * @return
     * @throws BeansException
     */
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> targeClass = bean.getClass();
        Field[] fields = targeClass.getDeclaredFields();
        for (Field field : fields) {
            ////判断属性是否是自定义注解@Autowired
            if (field.isAnnotationPresent(Autowired.class)) {
                //加自定义注解的属性必须是接口类型（这样才可能出现多个不同的实例bean)
                if (!field.getType().isInterface()) {
                    throw new BeanCreationException("Autowired field must be declared an interface");
                } else {
                    try {
                        //为属性赋值
                        this.hanldAutowired(field, bean, field.getType());
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return bean;
    }

    private void hanldAutowired(Field field, Object bean, Class type) throws IllegalAccessException {
//        //获取所有该属性接口的实例bean
//        Map<String, Object> beans = this.applicationContext.getBeansOfType(type);
//        //设置该域可设置修改
//        field.setAccessible(true);
//        //获取注解@Autowired中配置的value值
//        String injectVal = field.getAnnotation(Autowired.class).value();
//        //将找到的实例赋值给属性域
//        field.set(bean, beans.get(injectVal));
    }

}
