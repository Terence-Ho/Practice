package com.lagou.edu.servlet;

import com.lagou.edu.Annotation.Service;
import com.lagou.edu.factory.BeanFactoryAnno;
import com.lagou.edu.service.TransferService;
import org.junit.Test;

@Service(value = "testInit")
public class TestInit {

//    @Autowired
//    private TransferService transferService;

    @Test
    public void beanFactoryTest() {
        try {
            BeanFactoryAnno.initScan("com.lagou.edu");

            TransferService transferService =(TransferService) BeanFactoryAnno.getBean("transferService");
            transferService.transfer("6029621011000","6029621011001",100);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
